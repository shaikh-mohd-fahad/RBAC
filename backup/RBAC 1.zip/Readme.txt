This is a overview of project called RBAC
Dear HR, i am a final year student. I tried my best to make this project within given period of time. I know it has lack. and can be made more better. Right now I dont have any mentor to guide me. if i got chance to work in you company i will get mentor their and under the guidance of mentor i can make more advance websites with more functionality, security etc

                                        *************

Start React
cd frontend
npm run dev

                                        *************

start json server
cd frontend
json-server --watch db.json --port 3000

                                        *************
Working of website.
Website contain home page and admin section
1. on home page, their is a admin dashboard menu. when click on it. it open admin section.
2. Admin section has 4 sidebar/part. 
    Dashboard: to see the overview of complete website.
    All User : Here we see list of all users, and here we also create, edit and delete user.
    Role

